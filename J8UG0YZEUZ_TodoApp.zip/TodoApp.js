let todoItemsContainer = document.getElementById("todoItemsContainer");
let addTodoButton = document.getElementById("addTodoButton");
let saveTodoButton = document.getElementById("saveTodoButton");

saveTodoButton.onclick = function() {
    localStorage.setItem('todoList', JSON.stringify(todoList));
};

function getTodoListFromLocalStorage() {
    let stringifyTodoList = localStorage.getItem('todoList');
    let parseTodoList = JSON.parse(stringifyTodoList);
    if (parseTodoList === null) {
        return [];
    } else {
        return parseTodoList;
    }
}

let todoList = getTodoListFromLocalStorage();

let todosCount = todoList.length;

function onTodoStatusChange(checkboxId, labelId, todoId) {
    let labelElement = document.getElementById(labelId);
    let todoIdIndex = todoList.findIndex(function(eachTodo) {
        if (todoId === "todo" + eachTodo.uniqueNo) {
            return true;
        } else {
            return false;
        }
    });

    let todoElement = todoList[todoIdIndex];
    if (todoElement.isChecked === true) {
        todoElement.isChecked = false;
    } else {
        todoElement.isChecked = true;
    }
    labelElement.classList.toggle('checked');
}

function onDeleteTodo(todoId) {
    let todoElement = document.getElementById(todoId);
    let deleteTodoIndex = todoList.findIndex(function(todoList) {
        if (todoId === "todo" + todoList.uniqueNo) {
            return true;
        } else {
            return false;
        }
    });
    todoList.splice(deleteTodoIndex, 1);
    todoItemsContainer.removeChild(todoElement);

}

function createAndAppendTodo(todo) {
    let todoId = 'todo' + todo.uniqueNo;
    let checkboxId = 'checkbox' + todo.uniqueNo;
    let labelId = 'label' + todo.uniqueNo;

    let todoElement = document.createElement("li");
    todoElement.classList.add("todo-item-container", "d-flex", "flex-row");
    todoElement.id = todoId;
    todoItemsContainer.appendChild(todoElement);

    let inputElement = document.createElement("input");
    inputElement.type = "checkbox";
    inputElement.checked = todo.isChecked;
    inputElement.id = checkboxId;

    inputElement.onclick = function() {
        onTodoStatusChange(checkboxId, labelId, todoId);
    };

    inputElement.classList.add("checkbox-input");
    todoElement.appendChild(inputElement);

    let labelContainer = document.createElement("div");
    labelContainer.classList.add("label-container", "d-flex", "flex-row");
    todoElement.appendChild(labelContainer);

    let labelElement = document.createElement("label");
    labelElement.setAttribute("for", checkboxId);
    labelElement.id = labelId;
    labelElement.classList.add("checkbox-label");
    labelElement.textContent = todo.text;
    if (todo.isChecked === true) {
        labelElement.classList.add("checked");
    }
    labelContainer.appendChild(labelElement);

    let deleteIconContainer = document.createElement("div");
    deleteIconContainer.classList.add("delete-icon-container");
    labelContainer.appendChild(deleteIconContainer);

    let deleteIcon = document.createElement("i");
    deleteIcon.classList.add("far", "fa-trash-alt", "delete-icon");

    deleteIcon.onclick = function() {
        onDeleteTodo(todoId);
    };

    deleteIconContainer.appendChild(deleteIcon);
}

for (let todo of todoList) {
    createAndAppendTodo(todo);
}

function onAddTodo() {
    let userInputElement = document.getElementById("todoUserInput");
    let userInputValue = userInputElement.value;

    if (userInputValue === "") {
        alert("Enter Valid Text");
        return;
    }

    todosCount = todosCount + 1;

    let newTodo = {
        text: userInputValue,
        uniqueNo: todosCount,
        isChecked: false
    };
    todoList.push(newTodo);
    createAndAppendTodo(newTodo);
    userInputElement.value = "";
}

addTodoButton.onclick = function() {
    onAddTodo();
}